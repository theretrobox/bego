import React, { useEffect, useMemo, useState } from 'react'
import { auth, db } from './firebase'
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
} from 'firebase/auth'
import {
  addDoc, collection, deleteDoc, doc, getDoc, getDocs,
  onSnapshot, orderBy, query, serverTimestamp, setDoc, updateDoc
} from 'firebase/firestore'

const currency = (n) => new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP' }).format(n || 0)

const CONDITIONS = ['New','Like new','Very good','Good','Fair','Refurbished']
const CATEGORIES = ['Consoles','Audio','Clothing','Accessories','Other']
const SHIPPING_METHODS = [
  { id: 'rm2', name: 'Royal Mail 2nd Class', desc: '2-3 working days (UK)', defaultPrice: 3.49 },
  { id: 'rm1', name: 'Royal Mail 1st Class', desc: '1-2 working days (UK)', defaultPrice: 4.79 },
  { id: 'courier', name: 'Courier Tracked', desc: 'Tracked, 2-4 days', defaultPrice: 6.99 },
  { id: 'collect', name: 'Local collection', desc: 'Arrange collection', defaultPrice: 0.00 },
]

function Badge({ children }) {
  return <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-700 text-xs border">{children}</span>
}

function Header({ onNav, user }) {
  return (
    <header className="sticky top-0 z-30 bg-white/70 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
        <button onClick={() => onNav('home')} className="text-xl font-black tracking-tight">the<strong className="text-indigo-600">retro</strong>box</button>
        <nav className="ml-6 hidden md:flex gap-4 text-sm">
          <button onClick={() => onNav('browse')} className="hover:underline">Browse</button>
          {user && <button onClick={() => onNav('sell')} className="hover:underline">List an item</button>}
          <button onClick={() => onNav('about')} className="hover:underline">About</button>
          {user && <button onClick={() => onNav('orders')} className="hover:underline">Orders</button>}
        </nav>
        <div className="ml-auto flex items-center gap-2 text-sm">
          {user ? (
            <>
              <span className="text-gray-600">Signed in as {user.email}</span>
              <button onClick={() => signOut(auth)} className="px-3 py-1.5 rounded-xl border">Sign out</button>
            </>
          ) : (
            <button onClick={() => onNav('login')} className="px-3 py-1.5 rounded-xl border">Seller login</button>
          )}
        </div>
      </div>
    </header>
  )
}

function SearchBar({ q, setQ, category, setCategory }) {
  return (
    <div className="flex flex-col md:flex-row gap-3">
      <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Search listings…" className="w-full border rounded-xl px-3 py-2" />
      <select value={category} onChange={(e)=>setCategory(e.target.value)} className="border rounded-xl px-3 py-2 w-full md:w-48">
        {['All', ...CATEGORIES].map(c => <option key={c}>{c}</option>)}
      </select>
    </div>
  )
}

function ListingCard({ item, onOpen }) {
  return (
    <button onClick={()=>onOpen(item)} className="text-left bg-white rounded-2xl shadow-sm hover:shadow-md transition border overflow-hidden">
      <div className="aspect-square bg-gray-100 overflow-hidden">
        <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
      </div>
      <div className="p-3">
        <h3 className="font-semibold line-clamp-1">{item.title}</h3>
        <div className="flex items-center justify-between mt-1">
          <span className="font-bold">{currency(item.price)}</span>
          <Badge>{item.condition}</Badge>
        </div>
        <p className="text-xs mt-1 text-gray-500">{item.location}</p>
      </div>
    </button>
  )
}

function ListingGrid({ items, onOpen }) {
  if (!items.length) return <p className="text-gray-500">No items found.</p>
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {items.map(it => <ListingCard key={it.id} item={it} onOpen={onOpen} />)}
    </div>
  )
}

function SizeGuideModal({ open, onClose }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-3xl w-full p-6" onClick={(e)=>e.stopPropagation()}>
        <h3 className="text-xl font-bold mb-2">Size guides</h3>
        <p className="text-sm text-gray-600 mb-4">General UK sizing. Brands vary; measure a similar garment for best fit.</p>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div className="border rounded-xl p-4">
            <h4 className="font-semibold mb-2">Tops (Chest)</h4>
            <ul className="space-y-1 text-gray-700">
              <li>XS: 32–34"</li><li>S: 35–37"</li><li>M: 38–40"</li><li>L: 41–43"</li><li>XL: 44–46"</li>
            </ul>
          </div>
          <div className="border rounded-xl p-4">
            <h4 className="font-semibold mb-2">Bottoms (Waist)</h4>
            <ul className="space-y-1 text-gray-700">
              <li>28: 27–28"</li><li>30: 29–30"</li><li>32: 31–32"</li><li>34: 33–34"</li><li>36: 35–36"</li>
            </ul>
          </div>
        </div>
        <div className="text-right mt-4">
          <button onClick={onClose} className="px-4 py-2 rounded-xl border">Close</button>
        </div>
      </div>
    </div>
  )
}

function ItemModal({ item, onClose, onBuy }) {
  if (!item) return null
  const ship = SHIPPING_METHODS.find(s => s.id === item.shippingMethod)
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden" onClick={(e)=>e.stopPropagation()}>
        <div className="grid md:grid-cols-2">
          <img src={item.image} alt={item.title} className="w-full h-72 md:h-full object-cover" />
          <div className="p-5 space-y-3">
            <h3 className="text-xl font-semibold">{item.title}</h3>
            <div className="flex gap-2 text-sm text-gray-600 flex-wrap">
              <Badge>{item.category}</Badge>
              {item.brand && <Badge>{item.brand}</Badge>}
              {item.size && <Badge>{item.size}</Badge>}
              <Badge>{item.condition}</Badge>
            </div>
            <p className="text-sm text-gray-700">{item.desc}</p>
            <p className="text-xs text-gray-500">Location: {item.location}</p>
            {ship && (
              <p className="text-xs text-gray-600">
                Shipping: <strong>{ship.name}</strong> — {currency(item.shippingPrice ?? ship.defaultPrice)}
              </p>
            )}
            <div className="flex items-center justify-between pt-2">
              <span className="text-2xl font-bold">{currency(item.price)}</span>
              <button onClick={() => onBuy(item)} className="px-4 py-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700">Buy with SumUp</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function SellerForm({ onSaved, user }) {
  const [openSizeGuide, setOpenSizeGuide] = useState(false)
  const [form, setForm] = useState({
    title: '', price: '', size: '', condition: 'Good', category: 'Other', brand: '',
    image: '', desc: '', location: '', sumupLink: '',
    shippingMethod: 'rm2', shippingPrice: ''
  })
  async function handleSubmit(e) {
    e.preventDefault()
    const price = parseFloat(form.price || 0)
    const shippingPrice = form.shippingPrice === '' ? null : parseFloat(form.shippingPrice || 0)
    if (!form.title || !form.image || !price) return alert('Please add a title, image URL and price.')
    const payload = {
      ...form,
      price,
      shippingPrice,
      sellerUid: user.uid,
      createdAt: serverTimestamp(),
    }
    await addDoc(collection(db, 'items'), payload)
    setForm({ title:'', price:'', size:'', condition:'Good', category:'Other', brand:'', image:'', desc:'', location:'', sumupLink:'', shippingMethod: 'rm2', shippingPrice: '' })
    onSaved && onSaved()
  }
  return (
    <div>
      <form onSubmit={handleSubmit} className="bg-white rounded-2xl border p-4 grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm">Title<input className="w-full border rounded-xl px-3 py-2" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} /></label>
          <label className="text-sm">Image URL<input className="w-full border rounded-xl px-3 py-2" value={form.image} onChange={e=>setForm({...form, image:e.target.value})} placeholder="https://…" /></label>
          <div className="grid grid-cols-3 gap-3">
            <label className="text-sm col-span-2">Price £<input className="w-full border rounded-xl px-3 py-2" type="number" step="0.01" value={form.price} onChange={e=>setForm({...form, price:e.target.value})} /></label>
            <label className="text-sm">Size
              <div className="flex gap-2">
                <input className="w-full border rounded-xl px-3 py-2" value={form.size} onChange={e=>setForm({...form, size:e.target.value})} />
                <button type="button" onClick={()=>setOpenSizeGuide(true)} className="px-3 py-2 rounded-xl border">Guide</button>
              </div>
            </label>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <label className="text-sm">Condition<select className="w-full border rounded-xl px-3 py-2" value={form.condition} onChange={e=>setForm({...form, condition:e.target.value})}>
              {CONDITIONS.map(c=><option key={c}>{c}</option>)}
            </select></label>
            <label className="text-sm">Category<select className="w-full border rounded-xl px-3 py-2" value={form.category} onChange={e=>setForm({...form, category:e.target.value})}>
              {CATEGORIES.map(c=><option key={c}>{c}</option>)}
            </select></label>
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-sm">Brand<input className="w-full border rounded-xl px-3 py-2" value={form.brand} onChange={e=>setForm({...form, brand:e.target.value})} /></label>
          <label className="text-sm">Location<input className="w-full border rounded-xl px-3 py-2" value={form.location} onChange={e=>setForm({...form, location:e.target.value})} placeholder="City" /></label>
          <label className="text-sm">Description<textarea className="w-full border rounded-xl px-3 py-2" rows="4" value={form.desc} onChange={e=>setForm({...form, desc:e.target.value})}></textarea></label>
          <label className="text-sm">SumUp payment link (optional)<input className="w-full border rounded-xl px-3 py-2" value={form.sumupLink} onChange={e=>setForm({...form, sumupLink:e.target.value})} placeholder="Paste link from your SumUp dashboard" /></label>
          <div className="grid grid-cols-2 gap-3">
            <label className="text-sm">Shipping method<select className="w-full border rounded-xl px-3 py-2" value={form.shippingMethod} onChange={e=>setForm({...form, shippingMethod:e.target.value})}>
              {SHIPPING_METHODS.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select></label>
            <label className="text-sm">Shipping price £<input className="w-full border rounded-xl px-3 py-2" type="number" step="0.01" value={form.shippingPrice} onChange={e=>setForm({...form, shippingPrice:e.target.value})} placeholder="Leave blank to use default" /></label>
          </div>
          <div className="flex gap-2 pt-2">
            <button className="px-4 py-2 rounded-xl bg-black text-white">Add listing</button>
          </div>
        </div>
      </form>
      <p className="text-xs text-gray-500 mt-2">Tip: Create a SumUp Payment Link for each item and paste it above. Buyers are taken to your secure SumUp checkout.</p>
      <SizeGuideModal open={openSizeGuide} onClose={()=>setOpenSizeGuide(false)} />
    </div>
  )
}

function OrdersDashboard({ user }) {
  const [orders, setOrders] = useState([])
  useEffect(() => {
    const qRef = query(collection(db, 'orders'), orderBy('createdAt', 'desc'))
    return onSnapshot(qRef, snap => {
      setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() })))
    })
  }, [])

  return (
    <section className="max-w-6xl mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-4">Orders</h2>
      <p className="text-sm text-gray-600 mb-4">Manual orders for now (since SumUp webhooks require a server). Mark items as sold or add an order when you ship.</p>
      <div className="bg-white border rounded-2xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left p-3">Date</th>
              <th className="text-left p-3">Item</th>
              <th className="text-left p-3">Buyer</th>
              <th className="text-left p-3">Total</th>
              <th className="text-left p-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(o => (
              <tr key={o.id} className="border-t">
                <td className="p-3">{o.createdAt?.toDate ? o.createdAt.toDate().toLocaleString() : ''}</td>
                <td className="p-3">{o.title}</td>
                <td className="p-3">{o.buyerName || ''} {o.buyerEmail ? `(${o.buyerEmail})` : ''}</td>
                <td className="p-3">{currency((o.price||0) + (o.shippingPrice||0))}</td>
                <td className="p-3">{o.status || 'pending'}</td>
              </tr>
            ))}
            {!orders.length && <tr><td colSpan="5" className="p-4 text-center text-gray-500">No orders yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  )
}

function Login({ onAuthed }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('login')
  async function submit(e) {
    e.preventDefault()
    if (mode === 'login') await signInWithEmailAndPassword(auth, email, password)
    else await createUserWithEmailAndPassword(auth, email, password)
    onAuthed && onAuthed()
  }
  return (
    <section className="max-w-md mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-2">{mode === 'login' ? 'Seller login' : 'Create seller account'}</h2>
      <form onSubmit={submit} className="bg-white rounded-2xl border p-4 space-y-3">
        <label className="text-sm">Email<input className="w-full border rounded-xl px-3 py-2" value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <label className="text-sm">Password<input type="password" className="w-full border rounded-xl px-3 py-2" value={password} onChange={e=>setPassword(e.target.value)} /></label>
        <button className="px-4 py-2 rounded-xl bg-black text-white">{mode === 'login' ? 'Login' : 'Create account'}</button>
      </form>
      <div className="text-sm text-gray-600 mt-2">
        {mode === 'login' ? (
          <button className="underline" onClick={()=>setMode('signup')}>Create a seller account</button>
        ) : (
          <button className="underline" onClick={()=>setMode('login')}>Already have an account? Login</button>
        )}
      </div>
    </section>
  )
}

export default function App() {
  const [route, setRoute] = useState('home')
  const [user, setUser] = useState(null)
  const [items, setItems] = useState([])
  const [openItem, setOpenItem] = useState(null)
  const [q, setQ] = useState('')
  const [category, setCategory] = useState('All')

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => setUser(u || null))
    return () => unsub()
  }, [])

  useEffect(() => {
    const qRef = query(collection(db, 'items'), orderBy('createdAt', 'desc'))
    return onSnapshot(qRef, snap => {
      setItems(snap.docs.map(d => ({ id: d.id, ...d.data() })))
    })
  }, [])

  const filtered = useMemo(() => {
    const needle = q.toLowerCase()
    return items.filter(it =>
      (category === 'All' || it.category === category) &&
      [it.title, it.brand, it.desc, it.location].some(f => (f || '').toLowerCase().includes(needle))
    )
  }, [items, q, category])

  async function onBuy(item) {
    if (item.sumupLink && /^https?:\/\//.test(item.sumupLink)) {
      window.open(item.sumupLink, '_blank')
      // Optional: create a placeholder order so you can reconcile later
      await addDoc(collection(db, 'orders'), {
        itemId: item.id,
        title: item.title,
        price: item.price,
        shippingMethod: item.shippingMethod,
        shippingPrice: item.shippingPrice ?? null,
        status: 'initiated',
        createdAt: serverTimestamp(),
      })
    } else {
      alert('No SumUp link set for this item yet. Edit the listing and paste a Payment Link from your SumUp dashboard.')
    }
  }

  return (
    <div className="min-h-screen">
      <Header onNav={setRoute} user={user} />

      {route === 'home' && (
        <section className="max-w-6xl mx-auto px-4 py-8">
          <div className="rounded-3xl p-8 bg-[linear-gradient(135deg,#eef2ff,#f0fdf4)] border">
            <h1 className="text-3xl md:text-4xl font-black tracking-tight">Buy & sell retro gear on theretrobox.co.uk</h1>
            <p className="mt-2 text-gray-600 max-w-2xl">A clean, minimal marketplace for vintage tech, fashion and audio. Create listings in seconds and accept payments using SumUp Payment Links.</p>
            <div className="mt-4 flex gap-3">
              <button onClick={() => setRoute('browse')} className="px-4 py-2 rounded-xl bg-black text-white">Browse listings</button>
              {user ? (
                <button onClick={() => setRoute('sell')} className="px-4 py-2 rounded-xl border">List an item</button>
              ) : (
                <button onClick={() => setRoute('login')} className="px-4 py-2 rounded-xl border">Seller login</button>
              )}
            </div>
          </div>
          <div className="mt-8 space-y-4">
            <div className="flex items-end justify-between gap-3">
              <div className="w-full"><SearchBar q={q} setQ={setQ} category={category} setCategory={setCategory} /></div>
            </div>
            <ListingGrid items={filtered} onOpen={setOpenItem} />
          </div>
        </section>
      )}

      {route === 'browse' && (
        <section className="max-w-6xl mx-auto px-4 py-8 space-y-4">
          <div className="flex items-end justify-between gap-3">
            <SearchBar q={q} setQ={setQ} category={category} setCategory={setCategory} />
          </div>
          <ListingGrid items={filtered} onOpen={setOpenItem} />
        </section>
      )}

      {route === 'sell' && user && (
        <section className="max-w-4xl mx-auto px-4 py-8 space-y-4">
          <h2 className="text-2xl font-bold">Create a listing</h2>
          <SellerForm user={user} onSaved={()=>setRoute('browse')} />
        </section>
      )}

      {route === 'orders' && user && <OrdersDashboard user={user} />}

      {route === 'about' && (
        <section className="max-w-3xl mx-auto px-4 py-8 space-y-3">
          <h2 className="text-2xl font-bold">About</h2>
          <p className="text-gray-700">This is a simple, Vinted‑style marketplace prototype for <strong>theretrobox.co.uk</strong>. It uses Firebase for authentication and Firestore for data storage.</p>
          <ul className="list-disc pl-5 text-gray-700">
            <li>Add/edit items (seller only), search, filter by category.</li>
            <li>Each item can link to a SumUp Payment Link for checkout.</li>
            <li>Orders dashboard (manual for now; add webhook later).</li>
          </ul>
        </section>
      )}

      {route === 'login' && !user && <Login onAuthed={()=>setRoute('sell')} />}

      <footer className="mt-10 text-center text-xs text-gray-500 py-10">
        <p>© {new Date().getFullYear()} theretrobox.co.uk — A simple community marketplace inspired by Vinted.</p>
      </footer>

      <ItemModal item={openItem} onClose={()=>setOpenItem(null)} onBuy={onBuy} />
    </div>
  )
}
