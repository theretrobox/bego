# The Retro Box — Vinted‑style Marketplace

Features:
- Listings with images, categories, conditions, sizes, and **shipping methods** (with default prices).
- **SumUp payment links** for checkout (paste from your SumUp dashboard).
- **Seller login** (Firebase Auth) and **Orders dashboard** (manual entries for now).
- **Firestore** database (Firebase) for items and orders.
- **Size guides** modal.
- SEO: meta description, Open Graph, robots.txt, sitemap.xml, canonical, analytics placeholder.

## Quick start

1) Install deps
```bash
npm install
```

2) Create `.env` from the example and fill with Firebase values
```bash
cp .env.example .env
```

3) Run locally
```bash
npm run dev
```

4) Build
```bash
npm run build
npm run preview
```

## Deploy (free)
- Vercel or Netlify: import the repo, build command `npm run build`.
- Point `theretrobox.co.uk` DNS to your hosting and set the custom domain.

## SumUp
- Create Payment Links in SumUp and paste the URL into each listing's **SumUp payment link**.
- For full automation (paid/fulfilled), you can later add a small server function + webhooks.

## Notes
- Open Graph tags are site-level in `index.html`. Per-item OG tags require server rendering.
- Tailwind is loaded via CDN for speed; switch to build-time Tailwind for production optimisation.
